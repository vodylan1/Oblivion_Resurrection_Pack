# Oblivion Core Codex — Phase 3 Update

## Logic Flow:
- Pipelines feed data → opportunity_monitor.py aggregates
- synergy_hooks.py evaluates signals → scoring.py assigns scores
- Signals > threshold become EXECUTION_REQUESTS (stubbed)

## Modules Involved:
- pipelines/
- sniper/core/opportunity_monitor.py
- sniper/core/synergy_hooks.py
- modules/SCORING_ENGINE/scoring.py
