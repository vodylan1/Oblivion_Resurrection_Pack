# Oblivion Core Codex
This file outlines the long-term blueprint for Oblivion's cognition, agents, mutation loop, and execution map.

GOD_EYE: Present in SCORING_ENGINE
GOD_AWARENESS: Present — pattern detection logic to feed into reflection/patch cycles
EGO_CORE + ARCHETYPE_MAPS: Supports strategy switching (Wick, Tywin, Ozymandias, Machiavelli)
GPT-4o API Uplink: gpt4o_connector.py + autopatch.py + strategy_mutations.py
Agents Scaffolded: Sentinel, Execution, Patchwright, Wallet, AlphaScout
Pipeline Feed Modules: Solana, Twitter, Telegram, LP trackers, Wallet mirror
Mutation Chain: SCORING_ENGINE → Execution → MEMORY_LOG_CORE → REFLECTION_ENGINE → PATCH_CORE → GPT Patch → Capsule Injection
