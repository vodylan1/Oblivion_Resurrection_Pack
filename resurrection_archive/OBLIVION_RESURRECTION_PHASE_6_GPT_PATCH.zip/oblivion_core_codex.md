# Oblivion Core Codex — Phase 6 Update

## GPT Integration Activated:
- OpenAI API key loaded from .env
- autopatch.py calls GPT for live mutation logic
- Results logged in PATCH_HISTORY
- PATCH_CORE connected to GPT response pipeline
